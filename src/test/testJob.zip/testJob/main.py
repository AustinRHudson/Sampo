print("Hello from MiniCloud!")
